// How a reward pool splits by place: the three ways the new proposal page offers (the cards Winner takes most,
// Recommended, Spread wide) and the one split of a pool over the top places, in cents, that the page, the server and the
// suggest service all compute the same way, so a pool turned into `prizes[]` anywhere pays the same cents.
//
// A leaf: no imports at all, so the server, the cli and the web app all read it.

/** The most places a split pays: contracts/sponsor-proposal.ts PROPOSAL_CAPS.prizes (tests/unit/payout-shapes.test.ts). */
export const PAYOUT_MAX_PLACES = 10;

/**
 * The prizes step's ways to split the pool (the owner's picks, 2026-11-05: the 'Presets' mockup, with the 'Slider'
 * mockup's places bar for more say): each place pays `ratio` of the one above it, and a pick starts on `places` places.
 */
export const PAYOUT_SHAPES = Object.freeze({
  top: { places: 3, ratio: 0.45 },
  balanced: { places: 5, ratio: 0.7 },
  flat: { places: PAYOUT_MAX_PLACES, ratio: 0.9 },
});
export type PayoutShape = keyof typeof PAYOUT_SHAPES;
/** The shapes as the page lays out their cards, left to right. */
export const PAYOUT_ORDER: readonly PayoutShape[] = ['top', 'balanced', 'flat'];
/** The shape the page pre-selects (its Recommended card), and the one a split read back prefers when several fit. */
export const RECOMMENDED_PAYOUT_SHAPE: PayoutShape = 'balanced';

/** The steps a split rounds places 2 on to, coarsest first, in cents: $100 down to the cent. */
const PAYOUT_STEPS = [10_000, 5_000, 1_000, 500, 100, 1] as const;

/** The most places a pool of `cents` pays: PAYOUT_MAX_PLACES, and at least a cent a place. */
export const maxPlacesOf = (cents: number): number => Math.max(1, Math.min(PAYOUT_MAX_PLACES, cents));

/**
 * `cents` split over the top `places` places (within maxPlacesOf) by `shape`, in cents, place 1 first: places 2 on
 * rounded to the coarsest step under a tenth of the smallest share (round numbers, each within 5% of its share), else to
 * whole dollars while the smallest share is one, else to the cent; place 1 takes what the rounding leaves, so the split
 * adds up to the pool and never pays a place more than the one above.
 */
export function splitPool(cents: number, shape: PayoutShape, places: number): number[] {
  const n = Math.min(Math.max(1, Math.round(places)), maxPlacesOf(cents));
  const ratio = PAYOUT_SHAPES[shape].ratio;
  const weights = Array.from({ length: n }, (_, i) => ratio ** i);
  const total = weights.reduce((a, b) => a + b, 0);
  const exact = weights.map((w) => (cents * w) / total);
  const smallest = exact[n - 1]!;
  for (const step of PAYOUT_STEPS.filter((s) => (s > 100 ? s * 10 : s) <= smallest || s === 1)) {
    const rest = exact.slice(1).map((v) => Math.max(step, Math.round(v / step) * step));
    const first = cents - rest.reduce((a, b) => a + b, 0);
    if (n === 1 || first >= rest[0]!) return [first, ...rest];
  }
  // A pool of a few cents a place: as even as whole cents go, the remainder to place 1.
  const even = Math.floor(cents / n);
  return [cents - even * (n - 1), ...Array<number>(n - 1).fill(even)];
}
